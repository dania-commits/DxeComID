import csv
from dataclasses import dataclass
from typing import List, Tuple


@dataclass
class Resource:
    name: str
    service: str
    region: str
    environment: str
    monthly_cost_sek: float
    avg_cpu_percent: float
    hours_per_day: float


@dataclass
class Recommendation:
    resource: Resource
    action: str
    rationale: str
    estimated_savings_sek: float


def load_resources(path: str) -> List[Resource]:
    resources: List[Resource] = []
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            resources.append(
                Resource(
                    name=row["name"],
                    service=row["service"],
                    region=row["region"],
                    environment=row["environment"],
                    monthly_cost_sek=float(row["monthly_cost_sek"]),
                    avg_cpu_percent=float(row["avg_cpu_percent"]),
                    hours_per_day=float(row["hours_per_day"]),
                )
            )
    return resources


def analyse_resource(r: Resource) -> List[Recommendation]:
    recs: List[Recommendation] = []

    # Rule 1: Underutilised in production, suggest rightsizing
    if r.environment == "prod" and r.avg_cpu_percent < 20 and r.monthly_cost_sek > 500:
        savings = r.monthly_cost_sek * 0.3  # assume 30 percent saving by downsizing
        recs.append(
            Recommendation(
                resource=r,
                action="Right-size",
                rationale=f"Production {r.service} has low average CPU ({r.avg_cpu_percent:.1f} percent) with relatively high cost.",
                estimated_savings_sek=savings,
            )
        )

    # Rule 2: Non production workloads, suggest schedule based optimisation
    if r.environment in {"dev", "test", "staging"} and r.hours_per_day > 10:
        # assume we can cut runtime by 40 percent by turning off outside office hours
        savings = r.monthly_cost_sek * 0.4
        recs.append(
            Recommendation(
                resource=r,
                action="Introduce schedule",
                rationale=f"{r.environment.capitalize()} {r.service} runs {r.hours_per_day:.0f} hours per day, could be parked outside office hours.",
                estimated_savings_sek=savings,
            )
        )

    # Rule 3: High cost, low utilisation in any environment
    if r.avg_cpu_percent < 10 and r.monthly_cost_sek > 1000:
        savings = r.monthly_cost_sek * 0.5
        recs.append(
            Recommendation(
                resource=r,
                action="Review usage",
                rationale=f"Very low utilisation ({r.avg_cpu_percent:.1f} percent) with high monthly cost.",
                estimated_savings_sek=savings,
            )
        )

    return recs


def build_report(resources: List[Resource]) -> Tuple[List[Recommendation], float]:
    all_recs: List[Recommendation] = []
    total_savings = 0.0
    for r in resources:
        recs = analyse_resource(r)
        all_recs.extend(recs)
        for rec in recs:
            total_savings += rec.estimated_savings_sek
    return all_recs, total_savings


def print_resources(resources: List[Resource]) -> None:
    print("Current resources")
    print("-" * 80)
    header = f"{'Name':25} {'Service':15} {'Env':8} {'Cost (SEK)':12} {'CPU (%)':8} {'Hours/day':10}"
    print(header)
    print("-" * 80)
    for r in resources:
        print(
            f"{r.name:25} {r.service:15} {r.environment:8} "
            f"{r.monthly_cost_sek:12.0f} {r.avg_cpu_percent:8.1f} {r.hours_per_day:10.1f}"
        )
    print()


def print_recommendations(recs: List[Recommendation], total_savings: float) -> None:
    if not recs:
        print("No optimisation recommendations were generated for the current dataset.")
        return

    print("Optimisation recommendations")
    print("-" * 80)
    header = f"{'Name':25} {'Action':18} {'Est. savings (SEK)':18} Rationale"
    print(header)
    print("-" * 80)
    for rec in recs:
        print(
            f"{rec.resource.name:25} {rec.action:18} "
            f"{rec.estimated_savings_sek:18.0f} {rec.rationale}"
        )
    print("-" * 80)
    print(f"Total potential monthly savings: {total_savings:.0f} SEK")
    print()


def main() -> None:
    data_path = "data/resources.csv"
    resources = load_resources(data_path)
    print_resources(resources)
    recs, total_savings = build_report(resources)
    print_recommendations(recs, total_savings)


if __name__ == "__main__":
    main()

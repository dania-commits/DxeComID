# Cloud Cost Optimization Simulator

Hi,

My name is Dania and this is a small cloud cost optimisation simulator I built as a personalised project.

The idea is simple: given a list of cloud resources with their current cost and utilisation, the script will:

- Highlight underutilised resources
- Suggest right sizing or schedule based optimisations
- Estimate potential monthly savings
- Produce a short summary report

The focus is on being practical and easy to understand rather than 100 percent realistic. The logic is intentionally transparent so that it is easy to extend with real data or additional rules.

## Project structure

- `main.py`  
  Entry point for the simulator. Reads the sample data, applies a few optimisation rules and prints a report.

- `data/resources.csv`  
  Example input data with a small set of virtual machines, databases and storage accounts. In a real scenario this could come from an export from a cloud provider.

- `requirements.txt`  
  Python dependencies for the project.

## How to run

1. Create and activate a virtual environment (recommended):

```bash
python -m venv .venv
source .venv/bin/activate   # On Windows: .venv\Scripts\activate
```

2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Run the simulator:

```bash
python main.py
```

You should see:

- A table with all resources and their utilisation
- Suggested optimisation actions with estimated savings
- A short summary at the end with total potential savings

## Input data format

If you want to test your own data, you can replace or extend `data/resources.csv`.  
The expected columns are:

- `name`  
- `service`  
- `region`  
- `environment` (for example: prod, staging, dev, test)  
- `monthly_cost_sek`  
- `avg_cpu_percent`  
- `hours_per_day` (typical active hours)  

You can add more rows or modify existing ones. The script is small and easy to adjust if the structure changes.

## Notes

- All amounts are in SEK for simplicity.
- The rules are intentionally simple but capture typical cost patterns:
  - low utilisation in production  
  - non production workloads that can be parked outside office hours  
  - resources with high cost but low average CPU

My goal with this project was to show how I think about cloud costs, optimisation levers and how to turn data into something actionable and easy to discuss with a team.

Best regards,  
Dania

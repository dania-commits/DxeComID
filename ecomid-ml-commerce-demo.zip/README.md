# Agentic Fashion Demo – End to End ML Prototype

Hi, I am **Dania**, and this is a small end to end project I built to explore ideas that are very close to what eComID is working on: agentic commerce, AI sizing and dynamic pricing.

The goal of the project is not to be perfect or complete, but to show how I think about:

- turning real business questions into concrete ML and engineering tasks  
- designing simple but extensible architectures  
- keeping things production friendly and easy to reason about  

The whole project is intentionally lightweight and can be started locally with only Python and a browser.

---

## What the project does

The demo focuses on three core flows:

1. **Size recommendation**
   - Simple body profile input (height, weight, fit preference).
   - Minimal product catalogue with size charts.
   - A heuristic model that estimates chest circumference and picks the best matching size.
   - Returns a size, a confidence score and a short explanation.

2. **Dynamic pricing**
   - Small pricing service that takes base price, inventory level, daily views and conversion rate.
   - Applies transparent rules to adjust the price factor.
   - Returns a recommended price together with a short reasoning string.

3. **Shopping agent explanation**
   - A lightweight rule based "agent" that explains how it thinks about fit for a given product.
   - Uses the product metadata, user profile and a natural language question.
   - In a real system this is where I would plug in an LLM that is grounded in product and behavioural data.

All of this is exposed through a small FastAPI backend and a minimal frontend, just enough to click around and see behaviour.

---

## Tech stack

**Backend**

- Python  
- FastAPI  
- Pydantic models  
- Simple in memory product catalogue in JSON  

**Frontend**

- Static HTML  
- A bit of vanilla JavaScript to call the API and render responses  

**ETL**

- A tiny script that normalises the product catalogue and adds style tags  
- For a real project I would replace the rule based part with an LLM powered enrichment step  

I deliberately kept the stack compact so that it is quick to set up and easy to read in one sitting.

---

## Project structure

```text
ecomid-ml-commerce-demo/
├── backend
│   ├── app
│   │   ├── api
│   │   │   ├── agent.py
│   │   │   ├── pricing.py
│   │   │   ├── products.py
│   │   │   └── size.py
│   │   ├── agent
│   │   │   └── service.py
│   │   ├── data
│   │   │   └── products.json
│   │   ├── models
│   │   │   └── schemas.py
│   │   ├── services
│   │   │   ├── dynamic_pricing.py
│   │   │   └── size_recommender.py
│   │   └── main.py
│   └── requirements.txt
├── etl
│   └── normalize_products.py
└── frontend
    └── index.html
```

---

## How to run it locally

1. Create and activate a virtual environment

   ```bash
   cd backend
   python -m venv .venv
   source .venv/bin/activate  # Windows: .venv\Scripts\activate
   ```

2. Install dependencies

   ```bash
   pip install -r requirements.txt
   ```

3. Start the API

   ```bash
   uvicorn app.main:app --reload
   ```

   The backend will be available on `http://localhost:8000`.

4. Open the frontend

   - Open `frontend/index.html` directly in the browser, or  
   - Serve it with a simple static server (for example `python -m http.server` from the `frontend` folder).

5. Try the flows

   - Pick a product in the size recommendation card and tweak height, weight and fit preference.  
   - Play with inventory level, views and conversion rate in the pricing card.  
   - Ask the shopping agent a natural language question about fit and comfort.  

---

## Design choices

- I favoured **clarity over complexity**. The models are simple on purpose so that the behaviour is easy to inspect and debug.
- The size recommendation logic is implemented as a deterministic function. I prefer to start with a clear baseline before moving to data driven models.
- The pricing service uses explicit factors (demand, inventory, conversion) that can be tuned step by step.
- The agent response is rule based at the moment, but I structured it so that swapping the internals with an LLM later would be straightforward.

If I had more time and access to real behavioural data I would extend this with:

- a proper model training pipeline for size prediction  
- a bandit or RL based pricing approach  
- evaluation scripts and dashboards  
- an LLM based ETL layer that cleans and enriches product copy at scale  

---

## Why this project

I wanted a small but concrete playground that touches the same themes that excite me about e commerce and AI:

- connecting ML to real business levers (conversion, returns, stock)  
- building systems that can actually be shipped and iterated on  
- keeping the architecture thoughtful but pragmatic  

I am happy to walk through the code, discuss trade offs and talk about how I would grow this into a production grade system.

— Dania
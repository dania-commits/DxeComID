from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .api import size, pricing, products, agent

app = FastAPI(title="Agentic Fashion Demo", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(size.router, prefix="/api/size", tags=["size"])
app.include_router(pricing.router, prefix="/api/pricing", tags=["pricing"])
app.include_router(products.router, prefix="/api/products", tags=["products"])
app.include_router(agent.router, prefix="/api/agent", tags=["agent"])

@app.get("/")
def root():
    return {"message": "Agentic Fashion Demo backend is running"}
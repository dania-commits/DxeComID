import json
import os
from fastapi import APIRouter, HTTPException

router = APIRouter()

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "products.json")


def _load_products():
    with open(DATA_PATH, "r") as f:
        return json.load(f)


@router.get("/")
def list_products():
    return _load_products()


@router.get("/{product_id}")
def get_product(product_id: str):
    products = _load_products()
    for p in products:
        if p["id"] == product_id:
            return p
    raise HTTPException(status_code=404, detail="Product not found")
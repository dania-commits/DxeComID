from fastapi import APIRouter
from ..models.schemas import DynamicPricingRequest, DynamicPricingResponse
from ..services.dynamic_pricing import recommend_price

router = APIRouter()


@router.post("/", response_model=DynamicPricingResponse)
def recommend(req: DynamicPricingRequest):
    price, factor, reasoning = recommend_price(req)
    return DynamicPricingResponse(
        recommended_price=price,
        price_factor=factor,
        reasoning=reasoning,
    )
from fastapi import APIRouter
from ..models.schemas import AgentQuery
from ..agent.service import generate_agent_answer

router = APIRouter()


@router.post("/explain")
def explain(query: AgentQuery):
    answer = generate_agent_answer(query.user, query.query, query.product_id)
    return {"answer": answer}
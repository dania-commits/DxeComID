from fastapi import APIRouter, HTTPException
from ..models.schemas import SizeRecommendationRequest, SizeRecommendationResponse
from ..services.size_recommender import recommend_size

router = APIRouter()


@router.post("/", response_model=SizeRecommendationResponse)
def recommend(req: SizeRecommendationRequest):
    try:
        size, confidence, reasoning = recommend_size(req.user, req.product_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return SizeRecommendationResponse(
        recommended_size=size,
        confidence=confidence,
        reasoning=reasoning,
    )
import json
import os
from typing import Dict

from ..models.schemas import UserBodyProfile

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "products.json")


def _load_products() -> Dict[str, dict]:
    with open(DATA_PATH, "r") as f:
        items = json.load(f)
    return {item["id"]: item for item in items}


PRODUCTS = _load_products()


def generate_agent_answer(user: UserBodyProfile, query: str, product_id: str) -> str:
    product = PRODUCTS.get(product_id)
    if not product:
        return "I could not find that product, but in general I look at fit, material and your body profile before suggesting a size."

    lines = []
    lines.append(f"You asked: '{query}'.")
    lines.append(
        f"For {product['name']} ({product['fit']} fit, {product['material']}), I start from your height {user.height_cm} cm and weight {user.weight_kg} kg."
    )

    if user.fit_preference == "oversized":
        lines.append("Since you prefer an oversized fit, I bias slightly towards a roomier size.")
    elif user.fit_preference == "slim":
        lines.append("Since you prefer a slim fit, I avoid recommending overly loose sizes.")
    else:
        lines.append("You did not specify a strong fit preference, so I aim for a regular fit.")

    if product["category"] == "jeans":
        lines.append(
            "For jeans I pay extra attention to waist measurements and often recommend trying two adjacent sizes if you are between sizes."
        )
    elif product["category"] == "tshirt":
        lines.append(
            "For tops like t-shirts I focus primarily on chest circumference and how much ease you want around the shoulders."
        )

    lines.append(
        "In a production system this agent would combine your purchase history, returns, and click behaviour to refine the recommendation over time."
    )

    return " ".join(lines)
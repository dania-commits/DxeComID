from ..models.schemas import DynamicPricingRequest
from math import exp


def recommend_price(req: DynamicPricingRequest):
    demand_factor = min(req.daily_views / 100.0, 3.0)

    # Inventory pressure: low inventory -> higher price, high inventory -> lower price
    if req.inventory_level <= 5:
        inventory_factor = 1.15
    elif req.inventory_level <= 20:
        inventory_factor = 1.05
    elif req.inventory_level <= 50:
        inventory_factor = 1.0
    else:
        inventory_factor = 0.92

    # Conversion contribution: reward strong conversion rate
    conv_factor = 1.0 + max(min(req.conversion_rate - 0.02, 0.08), -0.02)

    # Aggregate
    price_factor = 1.0 + 0.08 * demand_factor
    price_factor *= inventory_factor
    price_factor *= conv_factor

    recommended_price = round(req.base_price * price_factor, 2)

    reasoning = (
        f"Base price {req.base_price} adjusted for demand, inventory and "
        f"conversion. Inventory level {req.inventory_level}, daily views "
        f"{req.daily_views}, conversion rate {req.conversion_rate:.3f}."
    )

    return recommended_price, price_factor, reasoning
import json
import os
from typing import Dict
from math import exp

from ..models.schemas import UserBodyProfile

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "products.json")


def _load_products() -> Dict[str, dict]:
    with open(DATA_PATH, "r") as f:
        items = json.load(f)
    return {item["id"]: item for item in items}


PRODUCTS = _load_products()


def estimate_chest_circumference(user: UserBodyProfile) -> float:
    """Very rough heuristic: chest circumference proportional to BMI and height.

    This is obviously not medically accurate, but works as a simple demo.
    """
    bmi = user.weight_kg / ((user.height_cm / 100) ** 2)
    # A simple affine mapping to chest circumference
    base = 0.55 * user.height_cm
    adjustment = (bmi - 22) * 0.7
    return base + adjustment


def recommend_size(user: UserBodyProfile, product_id: str):
    if product_id not in PRODUCTS:
        raise ValueError(f"Unknown product_id: {product_id}")

    product = PRODUCTS[product_id]
    size_chart = product["size_chart"]
    user_chest = estimate_chest_circumference(user)

    # Compute difference between user measurement and each size
    diffs = {size: abs(measure - user_chest) for size, measure in size_chart.items()}
    # Pick the size with minimal difference
    best_size = min(diffs, key=diffs.get)

    # Confidence: inverse of normalized difference
    max_diff = max(diffs.values()) or 1.0
    norm_diff = diffs[best_size] / max_diff
    confidence = float(exp(-norm_diff))  # between ~0.37 and 1

    # Adjust based on fit preference
    reasoning_parts = [
        f"Estimated chest circumference: {user_chest:.1f} cm.",
        f"Best match in size chart: {best_size} ({size_chart[best_size]} cm).",
    ]

    if user.fit_preference == "oversized":
        reasoning_parts.append(
            "User prefers oversized fit, so slightly larger sizes are acceptable."
        )
    elif user.fit_preference == "slim":
        reasoning_parts.append(
            "User prefers slim fit, so closer-fitting sizes are preferred."
        )

    reasoning = " ".join(reasoning_parts)

    return best_size, confidence, reasoning
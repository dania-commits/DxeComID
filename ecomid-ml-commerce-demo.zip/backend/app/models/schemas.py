from pydantic import BaseModel
from typing import Optional, Dict

class UserBodyProfile(BaseModel):
    height_cm: float
    weight_kg: float
    age: Optional[int] = None
    gender: Optional[str] = None
    fit_preference: Optional[str] = "regular"

class ProductFeatures(BaseModel):
    product_id: str
    category: str
    material: str
    fit: str
    size_chart: Dict[str, float]

class SizeRecommendationRequest(BaseModel):
    user: UserBodyProfile
    product_id: str

class SizeRecommendationResponse(BaseModel):
    recommended_size: str
    confidence: float
    reasoning: str

class DynamicPricingRequest(BaseModel):
    product_id: str
    base_price: float
    inventory_level: int
    daily_views: int
    conversion_rate: float

class DynamicPricingResponse(BaseModel):
    recommended_price: float
    price_factor: float
    reasoning: str

class AgentQuery(BaseModel):
    user: UserBodyProfile
    query: str
    product_id: str
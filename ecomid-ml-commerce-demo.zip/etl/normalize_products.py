"""Simple ETL script for normalising product data.

In a production setup I would use an LLM here to enrich each product with
a consistent taxonomy (style, use case, season, silhouette etc.).

For this demo I keep it deliberately lightweight and purely rule based so
that it is easy to run locally without external dependencies.
"""

import json
import os
from typing import List, Dict


THIS_DIR = os.path.dirname(__file__)
RAW_PATH = os.path.join(THIS_DIR, "..", "backend", "app", "data", "products.json")
OUTPUT_PATH = os.path.join(THIS_DIR, "normalized_products.json")


def load_raw() -> List[Dict]:
    with open(RAW_PATH, "r") as f:
        return json.load(f)


def enrich(product: Dict) -> Dict:
    category = product.get("category", "").lower()
    fit = product.get("fit", "").lower()
    material = product.get("material", "").lower()

    style_tags = []
    if category == "tshirt":
        style_tags.append("casual")
    if category == "jeans":
        style_tags.append("everyday")

    if "cotton" in material:
        style_tags.append("breathable")
    if "denim" in material:
        style_tags.append("durable")

    if fit == "oversized":
        style_tags.append("relaxed")
    elif fit == "slim":
        style_tags.append("tailored")

    enriched = dict(product)
    enriched["style_tags"] = sorted(set(style_tags))
    enriched["searchable_text"] = " ".join(
        [enriched["name"], enriched["brand"], category, material] + enriched["style_tags"]
    )
    return enriched


def main():
    raw = load_raw()
    enriched = [enrich(p) for p in raw]
    with open(OUTPUT_PATH, "w") as f:
        json.dump(enriched, f, indent=2)
    print(f"Wrote {len(enriched)} enriched products to {OUTPUT_PATH}")


if __name__ == "__main__":
    main()